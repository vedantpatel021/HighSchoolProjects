import java.awt.Point;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.awt.*;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class LightsOutGUI extends JFrame implements ActionListener{
  private JPanel panelMain;
  private JPanel panelOne;
  private JPanel panelTwo;
  private JButton restartButton;
  private JLabel gamesPlayed;
  private JLabel wins;
  private Board board;
  private static AUButton[] displayButtons = new AUButton[42];
  private static JLabel moveCounter = new JLabel("Turn: ");

  private static final int DEFAULT_HEIGHT = 750; //Top 100 will be used for text
	private static final int DEFAULT_WIDTH = 700; 

  private void initDisplay()	{
		panelMain = new JPanel() {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
			}
		};
    this.setSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
    panelMain.setVisible(true); 
    panelOne = new JPanel();
    panelTwo = new JPanel();
  }

  public static void winTheGameRed(){
    for (int i = 0; i < Board.getBoard().length; i++){
      for (int j = 0; j < Board.getBoard()[i].length; j++){
        Board.getBoard()[i][j].changeToRedWinIcon();
        moveCounter.setText("Winner: Red");
      }
    }
  }

  public static void winTheGameYellow(){
    for (int i = 0; i < Board.getBoard().length; i++){
      for (int j = 0; j < Board.getBoard()[i].length; j++){
        Board.getBoard()[i][j].changeToYellowWinIcon();
        moveCounter.setText("Winner: Yellow");
      }
    }
  }

  public void actionPerformed(ActionEvent e){
    //LEAVE BLANK
  }

  public static void updateMoves(){
    moveCounter.setText("Turn: " + Board.getTurns());
  }

  public void displayGame() {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				setVisible(true); 
			}
		});
	}
  
  public LightsOutGUI(Board gameBoard){
    super("LightsOut");
    board = gameBoard;
    initDisplay();
    panelMain.setLayout(new BorderLayout());
    moveCounter = new JLabel("Turn: " + Board.getTurns());
    panelMain.add(moveCounter, BorderLayout.NORTH); // JLabel does not update with each move
    panelOne.setLayout(new GridLayout(6, 7));
    for (int i = 0; i < Board.getBoard().length; i++){
      for (int j = 0; j < Board.getBoard()[0].length; j++){
        panelOne.add(Board.getBoard()[i][j]);
      }//restartButton = new JButton();
    }
    panelMain.add(panelOne, BorderLayout.SOUTH);
    panelTwo.setLayout(new GridLayout(1, 1));//this cuh ben be tripping beans my cuh zins my original gangsta
    
    RestartButton restartButton = new RestartButton();
		restartButton.setText("Restart");
		panelTwo.add(restartButton);
		restartButton.setPreferredSize(new Dimension(100, 50));
    panelMain.add(panelTwo, BorderLayout.CENTER);
    add(panelMain);
  }
}
  /*
  MESSAGE FOR BEN:
  
  We should make our own buttons because its probably gonna make it easier to put images in it   and make methods outselves that tell us what the i and j index is that we pass to the          "click" method in Board.java
  
  Thoughts?
  */