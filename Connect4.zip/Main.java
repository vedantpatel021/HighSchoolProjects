public class Main {
  public static void main(String[] args) {
    Board boardOne = new Board();
    LightsOutGUI test = new LightsOutGUI(boardOne);
    test.displayGame();
  }
}
