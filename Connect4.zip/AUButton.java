import javax.swing.*;
import java.awt.event.*;

public class AUButton extends JButton implements ActionListener{
  private ImageIcon red;
  private ImageIcon yellow;
  private ImageIcon empty;
  private ImageIcon redCoinWin;
  private ImageIcon yellowCoinWin;
  private ImageIcon currentIcon;
  private int currentIndex;
  private static int index = 0;

  public AUButton(){
    red = new ImageIcon(this.getClass().getResource("redCoin.png"));
    yellow = new ImageIcon(this.getClass().getResource("yellowCoin.png"));
    empty = new ImageIcon(this.getClass().getResource("empty.jpeg"));
    redCoinWin = new ImageIcon(this.getClass().getResource("redCoinWin.png"));
    yellowCoinWin = new ImageIcon(this.getClass().getResource("yellowCoinWin.png"));
    setIcon(empty);
    currentIcon = empty;
    currentIndex = index;
    index++;
    this.addActionListener(this);
  }

  public void setYellow(){
    setIcon(yellow);
    currentIcon = red;
  }

  public void setRed(){
    setIcon(red);
    currentIcon = red;
  }

  public void setEmpty(){
    setIcon(empty);
    currentIcon = empty;
  }

  public void changeToRedWinIcon(){
    setIcon(redCoinWin);
  }

  public void changeToYellowWinIcon(){
    setIcon(yellowCoinWin);
  }

  public String getColor(){
    if (currentIcon.equals(yellow)){
      return "Yellow";
    }
    else if (currentIcon.equals(red)){
      return "Red";
    }
    else {
      return "Empty";
    }
  }

  public void setColor(String x){
    if (x.equals("Yellow")){
      setIcon(yellow);
      currentIcon = yellow;
    }
    else {
      setIcon(red);
      currentIcon = red;
    }
  }

  public boolean empty(){
    if (currentIcon.equals(empty)){
      return true;
    }
    return false;
  }

  public void actionPerformed(ActionEvent e){
    Board.click(currentIndex);
    LightsOutGUI.updateMoves();
    if (Board.checkWinRed()){
      Board.setGameWon(true);
      LightsOutGUI.winTheGameRed();
    }
    else if (Board.checkWinYellow()){
      LightsOutGUI.winTheGameYellow();
    }
  }

  public void changeColor(){
    if (currentIcon.equals(yellow)){
      setIcon(red);
      currentIcon = red;
    }
    else {
      setIcon(yellow);
      currentIcon = yellow;
    }
  }
}