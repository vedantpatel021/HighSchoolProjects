import javax.swing.*;
import java.awt.event.*;

public class RestartButton extends JButton implements ActionListener{
  
  public RestartButton (){
    this.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e){
    Board.scramble();
  }

}