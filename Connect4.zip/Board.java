import java.util.*;
import java.lang.*;
import javax.swing.*;

import java.awt.event.*;

public class Board{
  private static AUButton[][] buttons = new AUButton[6][7];
  private static int turn;
  private static boolean gameWon;
  private final int maxx = 7;
  private final int maxy = 6;

  public Board(){
    for (int i = 0; i < 6; i++){
      for (int j = 0; j < 7; j++){
        buttons[i][j] = new AUButton();
      }
    }
    int turn = 0;
    gameWon = false;
  }

  public static AUButton[][] getBoard(){
    return buttons;
  }

  public static boolean fullColumn(int x){
    for (int i = 0; i < 6; i++){
      if (buttons[i][x].getColor().equals("Empty")){
        return false;
      }
    }
    return true;
  }

  public static void click(int i){
    int j = findJ(i);
    i = findI(i);
    if (!gameWon){
      if (!fullColumn(j)){
        if (j == 0){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 1){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 2){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 3){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 4){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 5){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        if (j == 6){
          for (int k = 5; k >= 0; k--){
            if (buttons[k][j].empty()){
              buttons[k][j].setColor(getTurns());
              break;
            }
          }
        }
        changeTurns(1);
      }
    }
  }

  public static String getTurns(){
    if (turn % 2 == 0){
      return "Yellow";
    }
    return "Red";
  }

  public static void changeTurns(int x){
    turn += x;
  }

  public static void setGameWon(boolean x){
    gameWon = x;
  }

  public static void scramble(){
    for (int i = 0; i < 6; i++){
      for (int j = 0; j < 7; j++){
        buttons[i][j].setEmpty();
      }
    }
    turn = 0;
    LightsOutGUI.updateMoves();
    gameWon = false;
  }

  public static boolean checkWinYellow(){
    int streak = 0;
    for (int r = 0; r < 7; r++){
      for (int k = 0; k < 6; k++){
        if (buttons[k][r].getColor().equals("Yellow")){ // Vertical Yellow
          streak++;
        }
        else{
          streak = 0;
        }
        if (streak == 4){
          return true;
        }
      }
      streak = 0;
    }
    for (int r = 0; r < 6; r++){
      for (int k = 0; k < 7; k++){
        if (buttons[r][k].getColor().equals("Yellow")){ //Horizontal Yellow
          streak++;
        }
        else{
          streak = 0;
        }
        if (streak == 4){
          return true;
        }
      }
      streak = 0;
    }
    for (int row = 0; row < buttons.length - 3; row++){
      for (int col = 0; col < buttons[row].length - 3; col++){
        if ("Yellow".equals(buttons[row][col].getColor()) && "Yellow".equals(buttons[row + 1][col + 1].getColor()) && "Yellow".equals(buttons[row + 2][col + 2].getColor()) && "Yellow".equals(buttons[row + 3][col + 3].getColor())){
          return true;
        }
      }
    }
    for (int row = 0; row < buttons.length - 3; row++){
      for (int col = 3; col < buttons[row].length; col++){
        if ("Yellow".equals(buttons[row][col].getColor()) && "Yellow".equals(buttons[row + 1][col - 1].getColor()) && "Yellow".equals(buttons[row + 2][col - 2].getColor()) && "Yellow".equals(buttons[row + 3][col - 3].getColor())){
          return true;
        }
      }
    }
    return false;
  }

  public static boolean checkWinRed(){
    int streak = 0;
    for (int r = 0; r < 6; r++){
      for (int k = 0; k < 7; k++){
        if (buttons[r][k].getColor().equals("Red")){ //Horizontal Red
          streak++;
        }
        else{
          streak = 0;
        }
        if (streak == 4){
          return true;
        }
      }
      streak = 0;
    }
    for (int r = 0; r < 7; r++){
      for (int k = 0; k < 6; k++){
        if (buttons[k][r].getColor().equals("Red")){ // Vertical Red
          streak++;
        }
        else{
          streak = 0;
        }
        if (streak == 4){
          return true;
        }
      }
      streak = 0;
    }

    for (int row = 0; row < buttons.length - 3; row++){
      for (int col = 0; col < buttons[row].length - 3; col++){
        if ("Red".equals(buttons[row][col].getColor()) && "Red".equals(buttons[row + 1][col + 1].getColor()) && "Red".equals(buttons[row + 2][col + 2].getColor()) && "Red".equals(buttons[row + 3][col + 3].getColor())){
          return true;
        }
      }
    }
    for (int row = 0; row < buttons.length - 3; row++){
      for (int col = 3; col < buttons[row].length; col++){
        if ("Red".equals(buttons[row][col].getColor()) && "Red".equals(buttons[row + 1][col - 1].getColor()) && "Red".equals(buttons[row + 2][col - 2].getColor()) && "Red".equals(buttons[row + 3][col - 3].getColor())){
          return true;
        }
      }
    }
    return false;
  }

  public static int findI(int x){
    if (x < 7){
      return 0;
    }
    if (x < 14){
      return 1;
    }
    if (x < 21){
      return 2;
    }
    if (x < 28){
      return 3;
    }
    if (x < 35){
      return 4;
    }
    return 5;
  }

  public static int findJ(int x){
    return x % 7;
  }
}